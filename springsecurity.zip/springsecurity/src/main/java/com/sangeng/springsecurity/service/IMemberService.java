package com.sangeng.springsecurity.service;

import com.sangeng.springsecurity.entity.Address;
import com.sangeng.springsecurity.entity.Membervip;
import com.baomidou.mybatisplus.extension.service.IService;
import com.sangeng.springsecurity.enty.ResponseResult;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author yj
 * @since 2022-03-06
 */
public interface IMemberService {
    ResponseResult Membervipupdate(Membervip membervip);
}
