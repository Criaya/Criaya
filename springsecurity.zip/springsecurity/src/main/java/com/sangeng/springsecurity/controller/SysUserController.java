package com.sangeng.springsecurity.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 用户表 前端控制器
 * </p>
 *
 * @author yj
 * @since 2022-03-06
 */
@RestController
@RequestMapping("/sysUser")
public class SysUserController {

}
