package com.sangeng.springsecurity.controller;


import com.sangeng.springsecurity.entity.Dict;
import com.sangeng.springsecurity.enty.ResponseResult;
import com.sangeng.springsecurity.service.impl.DictServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author yj
 * @since 2022-03-06
 */
@RestController
@RequestMapping("/dict")
public class DictController {
    @Autowired
    private DictServiceImpl dictServiceImp;

    @PostMapping("/insertdict")
    public ResponseResult insertdict(@RequestBody Dict dict) {
        return dictServiceImp.insertdict(dict);
    }

    @PutMapping("/updatedict")
    public ResponseResult updatedict(@RequestBody Dict dict) {
        return dictServiceImp.updatedict(dict);
    }

    @GetMapping("/selctdict")
    public ResponseResult seleteedict(Dict dict) {
        return dictServiceImp.selectdict();
    }

    @DeleteMapping("/deletedict")
    public ResponseResult deleteedict(@RequestParam("dictid") String dictid) {
        return dictServiceImp.deletedict(dictid);
    }
}
