package com.sangeng.springsecurity.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.sangeng.springsecurity.entity.Cat;
import com.sangeng.springsecurity.entity.Goods;
import com.sangeng.springsecurity.entity.Membervip;
import com.sangeng.springsecurity.enty.ResponseResult;
import com.sangeng.springsecurity.mapper.CatMapper;
import com.sangeng.springsecurity.mapper.GoodsMapper;
import com.sangeng.springsecurity.mapper.MembervipMapper;
import com.sangeng.springsecurity.service.ICatService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author yj
 * @since 2022-03-06
 */
@Service
public class CatServiceImpl implements ICatService {
    @Autowired
    private GoodsMapper goodsMapper;

    @Override
    public ResponseResult selectcat(String catid) {
        LambdaQueryWrapper<Goods> membervipLambdaQueryWrapper = new LambdaQueryWrapper<>();
        membervipLambdaQueryWrapper.eq(Goods::getCatId, catid);
        List<Goods> goods = goodsMapper.selectList(membervipLambdaQueryWrapper);
        return new ResponseResult(200, goods);
    }
}
