package com.sangeng.springsecurity.service;

import com.sangeng.springsecurity.entity.Goods;
import com.baomidou.mybatisplus.extension.service.IService;
import com.sangeng.springsecurity.enty.ResponseResult;
import org.springframework.web.multipart.MultipartFile;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author yj
 * @since 2022-03-06
 */
public interface IGoodsService {
    ResponseResult insertgods(Goods goods,String shopid,MultipartFile filename);
    ResponseResult selectgods(String shopid);
    ResponseResult updategods(Goods goods,MultipartFile filename);
    ResponseResult deletegods(Integer goodId);

}
