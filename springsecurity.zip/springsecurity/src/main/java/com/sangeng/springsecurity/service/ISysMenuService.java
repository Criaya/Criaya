package com.sangeng.springsecurity.service;

import com.sangeng.springsecurity.entity.SysMenu;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 菜单表 服务类
 * </p>
 *
 * @author yj
 * @since 2022-03-06
 */
public interface ISysMenuService extends IService<SysMenu> {

}
