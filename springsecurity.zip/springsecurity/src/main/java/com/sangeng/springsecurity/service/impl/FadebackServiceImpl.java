package com.sangeng.springsecurity.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.sangeng.springsecurity.entity.Fadeback;
import com.sangeng.springsecurity.entity.Membervip;
import com.sangeng.springsecurity.enty.ResponseResult;
import com.sangeng.springsecurity.mapper.FadebackMapper;
import com.sangeng.springsecurity.mapper.MembervipMapper;
import com.sangeng.springsecurity.service.IFadebackService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author yj
 * @since 2022-03-06
 */
@Service
public class FadebackServiceImpl implements IFadebackService {
    @Autowired
    private FadebackMapper fadebackMapper;
    @Autowired
    private MembervipMapper membervipMapper;

    @Override
    public ResponseResult insertfade(Fadeback fadeback, String id) {
        Membervip membervip = membervipMapper.selectById(id);
        fadeback.setMemberId(id);
        fadeback.setNickname(membervip.getNickname());
        fadeback.setTel(membervip.getTel());
        fadebackMapper.insert(fadeback);
        return new ResponseResult(200, "反馈成功");
    }

    @Override
    public ResponseResult selectfade() {
        List<Fadeback> fadebacks = fadebackMapper.selectList(null);
        return new ResponseResult(200, fadebacks);
    }

    @Override
    public ResponseResult selectonefade(String id) {
        LambdaQueryWrapper<Fadeback> fadebackLambdaQueryWrapper = new LambdaQueryWrapper<>();
        fadebackLambdaQueryWrapper.eq(Fadeback::getMemberId, id);
        List<Fadeback> fadebacks = fadebackMapper.selectList(fadebackLambdaQueryWrapper);
        return new ResponseResult(200, fadebacks);
    }

    @Override
    public ResponseResult updatefade(Fadeback fadeback) {
        LambdaQueryWrapper<Fadeback> fadebackLambdaQueryWrapper = new LambdaQueryWrapper<>();
        fadebackLambdaQueryWrapper.eq(Fadeback::getId, fadeback.getId());
        fadebackMapper.update(fadeback, fadebackLambdaQueryWrapper);
        return new ResponseResult(200, "反馈修改成功");
    }

    @Override
    public ResponseResult deletefade(Integer id) {
        fadebackMapper.deleteById(id);
        return new ResponseResult(200, "删除成功");
    }
}
