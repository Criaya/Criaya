package com.sangeng.springsecurity.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.UpdateWrapper;
import com.sangeng.springsecurity.entity.Address;
import com.sangeng.springsecurity.enty.ResponseResult;
import com.sangeng.springsecurity.mapper.AddressMapper;
import com.sangeng.springsecurity.service.IAddressService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author yj
 * @since 2022-03-06
 */
@Service
public class AddressServiceImpl implements IAddressService {

    @Autowired
    private AddressMapper addressMapper;

    @Override
    public ResponseResult adderssinsert(Address address, String memberid) {
        if (address.getIsDefault() == 0) {
            LambdaQueryWrapper<Address> addressLambdaQueryWrapper = new LambdaQueryWrapper<>();
            addressLambdaQueryWrapper.eq(Address::getMemberId, memberid);
            List<Address> addresses = addressMapper.selectList(addressLambdaQueryWrapper);
            for (Address addressess : addresses) {
                addressess.setIsDefault(1);
                addressMapper.update(addressess, null);
            }
        }
        address.setMemberId(memberid);
        addressMapper.insert(address);
        return new ResponseResult(200, "添加成功");
    }

    @Override
    public ResponseResult adderssselect(String memberId) {
        LambdaQueryWrapper<Address> addressLambdaQueryWrapper = new LambdaQueryWrapper<>();
        addressLambdaQueryWrapper.eq(Address::getMemberId, memberId);
        List<Address> addresses = addressMapper.selectList(addressLambdaQueryWrapper);
        return new ResponseResult(200, addresses);
    }

    @Override
    public ResponseResult addersssdelete(String addressId) {
        addressMapper.deleteById(addressId);
        return new ResponseResult(200, "删除成功");
    }

    @Override
    public ResponseResult adderssupdate(Address address, String id) {
        if (address.getIsDefault() == 0) {
            LambdaQueryWrapper<Address> select = new LambdaQueryWrapper<>();
            select.eq(Address::getMemberId, id);
            List<Address> addresses = addressMapper.selectList(select);
            for (Address addre : addresses) {
                LambdaQueryWrapper<Address> update = new LambdaQueryWrapper<>();
                update.eq(Address::getId, addre.getId());
                addre.setIsDefault(1);
                addressMapper.update(addre, update);
            }
        }
        LambdaQueryWrapper<Address> updates = new LambdaQueryWrapper<>();
        updates.eq(Address::getId, address.getId());
        addressMapper.update(address, updates);
        return new ResponseResult(200, "修改成功");
    }
}
