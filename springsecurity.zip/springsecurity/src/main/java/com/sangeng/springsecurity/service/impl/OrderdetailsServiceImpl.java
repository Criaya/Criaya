package com.sangeng.springsecurity.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.sangeng.springsecurity.entity.Orderdetails;
import com.sangeng.springsecurity.enty.ResponseResult;
import com.sangeng.springsecurity.mapper.OrderdetailsMapper;
import com.sangeng.springsecurity.service.IOrderdetailsService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author yj
 * @since 2022-03-06
 */
@Service
public class OrderdetailsServiceImpl implements IOrderdetailsService {
    @Autowired
    private OrderdetailsMapper orderdetailsMapper;

    @Override
    public ResponseResult selectorderdetail(String odrdecode) {
        LambdaQueryWrapper<Orderdetails> orderdetailsLambdaQueryWrapper = new LambdaQueryWrapper<>();
        orderdetailsLambdaQueryWrapper.eq(Orderdetails::getOrderCode, odrdecode);
        Orderdetails orderdetails = orderdetailsMapper.selectOne(orderdetailsLambdaQueryWrapper);
        return new ResponseResult(200, orderdetails);
    }
}
