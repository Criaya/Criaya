package com.sangeng.springsecurity.mapper;

import com.sangeng.springsecurity.entity.Cart;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author yj
 * @since 2022-03-06
 */
@Mapper
@Repository
public interface CartMapper extends BaseMapper<Cart> {
    List<Cart> selectcart(String memberid);
    Integer updatecart(Cart cart);
    Integer deletecart(Integer cartid);
}
