package com.sangeng.springsecurity.service.impl;

import com.sangeng.springsecurity.entity.SysMenu;
import com.sangeng.springsecurity.mapper.SysMenuMapper;
import com.sangeng.springsecurity.service.ISysMenuService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 菜单表 服务实现类
 * </p>
 *
 * @author yj
 * @since 2022-03-06
 */
@Service
public class SysMenuServiceImpl extends ServiceImpl<SysMenuMapper, SysMenu> implements ISysMenuService {

}
