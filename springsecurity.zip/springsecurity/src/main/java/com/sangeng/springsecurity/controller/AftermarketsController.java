package com.sangeng.springsecurity.controller;


import com.sangeng.springsecurity.entity.Aftermarkets;
import com.sangeng.springsecurity.enty.ResponseResult;
import com.sangeng.springsecurity.service.impl.AftermarketsServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author yj
 * @since 2022-03-06
 */
@RestController
@RequestMapping("/aftermarkets")
public class AftermarketsController {
    @Autowired
    private AftermarketsServiceImpl aftermarketsServiceImmp;

    @PostMapping("/aftermarketsinsert")
    public ResponseResult aftermarketinsert() {
        return aftermarketsServiceImmp.insertaftermarketsservice();
    }

    @PutMapping("/aftermarketupdate")
    public ResponseResult aftermarketupdate(@RequestBody Aftermarkets aftermarkets) {
        return aftermarketsServiceImmp.updateaftermarketsservice(aftermarkets);
    }

    @PostMapping("/aftermarketselect")
    public ResponseResult aftermarketselect() {
        return aftermarketsServiceImmp.selectaftermarketsservice();
    }

    @DeleteMapping("/aftermarketdelete")
    public ResponseResult aftermarketdelete(@RequestParam("afterid") String afterid) {
        return aftermarketsServiceImmp.delectaftermarketsservice(afterid);
    }

}
