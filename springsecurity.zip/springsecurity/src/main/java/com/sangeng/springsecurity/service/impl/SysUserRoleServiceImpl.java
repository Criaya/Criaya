package com.sangeng.springsecurity.service.impl;

import com.sangeng.springsecurity.entity.SysUserRole;
import com.sangeng.springsecurity.enty.ResponseResult;
import com.sangeng.springsecurity.mapper.SysUserRoleMapper;
import com.sangeng.springsecurity.service.ISysUserRoleService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author yj
 * @since 2022-03-06
 */
@Service
public class SysUserRoleServiceImpl implements ISysUserRoleService {
    @Autowired
    private SysUserRoleMapper sysUserRoleMapper;

    @Override
    public ResponseResult insertrole(SysUserRole sysUserRole) {
        sysUserRoleMapper.insert(sysUserRole);
        return new ResponseResult(200, "添加成功");
    }
}
