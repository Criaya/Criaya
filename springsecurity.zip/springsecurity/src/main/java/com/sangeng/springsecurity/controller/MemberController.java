package com.sangeng.springsecurity.controller;


import com.sangeng.springsecurity.entity.Membervip;
import com.sangeng.springsecurity.enty.ResponseResult;
import com.sangeng.springsecurity.service.impl.MemberServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author yj
 * @since 2022-03-06
 */
@RestController
@RequestMapping("/member")
public class MemberController {
    @Autowired
    private MemberServiceImpl memberServiceImp;

    @PutMapping("/memberupdate")
    @PreAuthorize("hasAuthority('system:user:index')")
    public ResponseResult memberupdate(@RequestBody Membervip membervip) {
        return memberServiceImp.Membervipupdate(membervip);
    }

}
