package com.sangeng.springsecurity.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.sangeng.springsecurity.entity.Goodspic;
import com.sangeng.springsecurity.enty.ResponseResult;
import com.sangeng.springsecurity.mapper.GoodspicMapper;
import com.sangeng.springsecurity.service.IGoodspicService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.List;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author yj
 * @since 2022-03-06
 */
@Service
public class GoodspicServiceImpl implements IGoodspicService {
    @Autowired
    private GoodspicMapper goodspicMapper;

    @Override
    public ResponseResult insertpic(Integer goodsid, MultipartFile[] filename) {
        if (filename.length <= 0) {
            return new ResponseResult(300, "没有图片");
        }
        Goodspic goodspic = new Goodspic();
        for (MultipartFile file : filename) {
            //上传地址并且地址写进数据库
            if (file.isEmpty()) {
                return new ResponseResult<>(300, "上传文件为空");
            }
            String originalFilename = file.getOriginalFilename();
            String fileName = System.currentTimeMillis() + "." + originalFilename.substring(originalFilename.lastIndexOf(".") + 1);
            String pathName = "D:\\springsecurity\\src\\main\\resources\\static\\";
            File dest = new File(pathName + fileName);
            String path;
            if (originalFilename.substring(originalFilename.lastIndexOf(".")).equals(".png") || originalFilename.substring(originalFilename.lastIndexOf(".")).equals(".gif") || originalFilename.substring(originalFilename.lastIndexOf(".")).equals(".jpg")) {
                if (dest.getParentFile().exists()) {
                    dest.getParentFile().mkdirs();
                }
                try {
                    file.transferTo(dest);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                path = "http://" + "localhost" + ":" + "8888/" + fileName;
                goodspic.setGoodsid(goodsid);
                goodspic.setPicsmid(path);
                goodspicMapper.insert(goodspic);
            } else {
                return new ResponseResult(300, "图片格式错误");
            }
        }
        return new ResponseResult(200, "添加成功");
    }

    @Override
    public ResponseResult updatepic(Goodspic goodspic, MultipartFile[] filename) {
        if (filename.length <= 0) {
            return new ResponseResult(300, "没有图片");
        }
        for (MultipartFile file : filename) {
            //上传地址并且地址写进数据库
            if (file.isEmpty()) {
                return new ResponseResult<>(300, "上传文件为空");
            }
            String originalFilename = file.getOriginalFilename();
            String fileName = System.currentTimeMillis() + "." + originalFilename.substring(originalFilename.lastIndexOf(".") + 1);
            String pathName = "D:\\springsecurity\\src\\main\\resources\\static\\";
            File dest = new File(pathName + fileName);
            String path;
            if (originalFilename.substring(originalFilename.lastIndexOf(".")).equals(".png") || originalFilename.substring(originalFilename.lastIndexOf(".")).equals(".gif") || originalFilename.substring(originalFilename.lastIndexOf(".")).equals(".jpg")) {
                if (dest.getParentFile().exists()) {
                    dest.getParentFile().mkdirs();
                }
                try {
                    file.transferTo(dest);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                path = "http://" + "localhost" + ":" + "8888/" + fileName;
                LambdaQueryWrapper<Goodspic> sgoodspicLambdaQueryWrapper = new LambdaQueryWrapper<>();
                sgoodspicLambdaQueryWrapper.eq(Goodspic::getGoodsid, goodspic.getGoodsid());
                List<Goodspic> goodspics = goodspicMapper.selectList(sgoodspicLambdaQueryWrapper);
                for (Goodspic goods : goodspics) {
                    LambdaQueryWrapper<Goodspic> goodspicLambdaQueryWrapper = new LambdaQueryWrapper<>();
                    goodspicLambdaQueryWrapper.eq(Goodspic::getPicsid, goods.getPicsid());
                    goodspic.setPicsmid(path);
                    goodspicMapper.update(goodspic, goodspicLambdaQueryWrapper);
                }

            } else {
                return new ResponseResult(300, "图片格式错误");
            }
        }
        return new ResponseResult(200, "修改成功");
    }

    @Override
    public ResponseResult selectpic(Integer goodsid) {
        LambdaQueryWrapper<Goodspic> goodspicLambdaQueryWrapper = new LambdaQueryWrapper<>();
        goodspicLambdaQueryWrapper.eq(Goodspic::getGoodsid, goodsid);
        List<Goodspic> goodspics = goodspicMapper.selectList(goodspicLambdaQueryWrapper);
        return new ResponseResult(200, goodspics);
    }

    @Override
    public ResponseResult deletepic(String goodspic) {
        LambdaQueryWrapper<Goodspic> goodspicLambdaQueryWrapper = new LambdaQueryWrapper<>();
        goodspicLambdaQueryWrapper.eq(Goodspic::getPicsid, goodspic);
        goodspicMapper.delete(goodspicLambdaQueryWrapper);
        return new ResponseResult(200, "删除成功 ");
    }
}
