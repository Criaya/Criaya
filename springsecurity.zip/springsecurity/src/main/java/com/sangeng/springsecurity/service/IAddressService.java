package com.sangeng.springsecurity.service;

import com.sangeng.springsecurity.entity.Address;
import com.baomidou.mybatisplus.extension.service.IService;
import com.sangeng.springsecurity.enty.ResponseResult;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author yj
 * @since 2022-03-06
 */
public interface IAddressService {
    ResponseResult adderssinsert(Address address,String memberid);

    ResponseResult adderssselect(String memberId);

    ResponseResult addersssdelete(String memberId);

    ResponseResult adderssupdate(Address address,String id);




}
