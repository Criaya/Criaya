package com.sangeng.springsecurity.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.sangeng.springsecurity.entity.Address;
import com.sangeng.springsecurity.entity.Express;
import com.sangeng.springsecurity.entity.Orderdetails;
import com.sangeng.springsecurity.entity.Orders;
import com.sangeng.springsecurity.enty.ResponseResult;
import com.sangeng.springsecurity.mapper.AddressMapper;
import com.sangeng.springsecurity.mapper.ExpressMapper;
import com.sangeng.springsecurity.mapper.OrderdetailsMapper;
import com.sangeng.springsecurity.mapper.OrdersMapper;
import com.sangeng.springsecurity.service.IOrderService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author yj
 * @since 2022-03-06
 */
@Service
public class OrderServiceImpl implements IOrderService {
    @Autowired
    private OrdersMapper ordersMapper;
    @Autowired
    private AddressMapper addressMapper;
    @Autowired
    private OrderdetailsMapper orderdetailsMapper;
    @Autowired
    private ExpressMapper expressMapper;

    @Override
    public ResponseResult ordersinsert(Orderdetails orderdetails, String memberid) {

        Random random = new Random();
        String OrderCode = "";
        for (int i = 0; i < 6; i++) {
            int i1 = random.nextInt(10);
            OrderCode += i1;
        }

        //订单详情
        orderdetails.setOrderCode(OrderCode);
        Double itemPrice = orderdetails.getItemPrice();
        Integer itemNum = orderdetails.getItemNum();
        Double totalPrice = itemNum * itemPrice;
        orderdetails.setTotal(totalPrice);
        orderdetailsMapper.insert(orderdetails);

        //订单
        Orders orders = new Orders();
        LambdaQueryWrapper<Address> lambdaQueryWrapper = new LambdaQueryWrapper<>();
        lambdaQueryWrapper.eq(Address::getMemberId, memberid);
        List<Address> addresses = addressMapper.selectList(lambdaQueryWrapper);

        for (Address address : addresses) {
            if (address.getIsDefault() == 0) {
                Integer id = address.getId();
                orders.setAddressId(id);
            }
        }
        orders.setMemberId(Integer.valueOf(memberid));
        orders.setOrderCode(OrderCode);
        orders.setPaymentMoney(totalPrice);
        ordersMapper.insert(orders);
        return new ResponseResult(200, "购买成功");
    }

    @Override
    public ResponseResult ordersupdate(Orders orders) {
        LambdaQueryWrapper<Orderdetails> orderdetailsLambdaQueryWrapper = new LambdaQueryWrapper<>();
        orderdetailsLambdaQueryWrapper.eq(Orderdetails::getOrderCode, orders.getOrderCode());
        Orderdetails orderdetails = orderdetailsMapper.selectOne(orderdetailsLambdaQueryWrapper);

        Express express = new Express();
        express.setExpressName(orders.getShippingName());
        express.setGoodsid(Integer.valueOf(orderdetails.getItemId()));
        expressMapper.insert(express);

        LambdaQueryWrapper<Orders> lambdaQueryWrapper = new LambdaQueryWrapper<>();
        lambdaQueryWrapper.eq(Orders::getId, orders.getId());
        ordersMapper.update(orders, lambdaQueryWrapper);
        return new ResponseResult(200, "修改成功");
    }

    @Override
    public ResponseResult ordersselect() {
        HashMap hashMap = new HashMap<String, Object>();
        List<Address> addresses = new ArrayList<>();
        List<Orders> orders = ordersMapper.selectList(null);
        for (Orders orders1 : orders) {
            Address address = addressMapper.selectById(orders1.getAddressId());
            addresses.add(address);
        }
        hashMap.put("address", addresses);
        hashMap.put("orders", orders);
        return new ResponseResult(200, hashMap);
    }

    @Override
    public ResponseResult cussselect(String id) {
        HashMap hashMap = new HashMap<String, Object>();
        LambdaQueryWrapper<Orders> ordersLambdaQueryWrapper = new LambdaQueryWrapper<>();
        ordersLambdaQueryWrapper.eq(Orders::getMemberId, id);
        Orders orders = ordersMapper.selectOne(ordersLambdaQueryWrapper);
        Address address = addressMapper.selectById(orders.getAddressId());
        hashMap.put("address", address);
        hashMap.put("orders", orders);
        if (orders.getFlag() == 1) {
            return new ResponseResult(200, hashMap);
        }
        return new ResponseResult(300, "还未发货");
    }

    @Override
    public ResponseResult ordersdelete(Orders orders) {
        String orderCode = orders.getOrderCode();
        LambdaQueryWrapper<Orders> ordersLambdaQueryWrapper = new LambdaQueryWrapper<>();
        ordersLambdaQueryWrapper.eq(Orders::getOrderCode, orders.getOrderCode());
        LambdaQueryWrapper<Orderdetails> ordersdelLambdaQueryWrapper = new LambdaQueryWrapper<>();
        Orderdetails orderdetails = new Orderdetails();
        ordersdelLambdaQueryWrapper.eq(Orderdetails::getOrderCode, orders.getOrderCode());
        ordersMapper.delete(ordersLambdaQueryWrapper);
        orderdetailsMapper.delete(ordersdelLambdaQueryWrapper);
        return new ResponseResult(200, "删除成功");
    }

}
