package com.sangeng.springsecurity.service;

import com.sangeng.springsecurity.entity.Cart;
import com.baomidou.mybatisplus.extension.service.IService;
import com.sangeng.springsecurity.enty.ResponseResult;

import java.util.List;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author yj
 * @since 2022-03-06
 */
public interface ICartService  {
     ResponseResult insertcart(Cart cart,String memberid);
     ResponseResult selectcart(String memberid);
     ResponseResult updatecart(Cart cart);
     ResponseResult deletecart(Integer cartid);
}
