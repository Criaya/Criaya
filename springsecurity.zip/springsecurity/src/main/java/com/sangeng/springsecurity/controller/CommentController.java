package com.sangeng.springsecurity.controller;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sangeng.springsecurity.annotation.CurrentUserId;
import com.sangeng.springsecurity.entity.Comment;
import com.sangeng.springsecurity.entity.Goods;
import com.sangeng.springsecurity.enty.ResponseResult;
import com.sangeng.springsecurity.service.impl.CommentServiceImpl;
import com.sangeng.springsecurity.service.impl.GoodsServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import org.springframework.web.multipart.MultipartFile;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author yj
 * @since 2022-03-06
 */
@RestController
@RequestMapping("/comment")
public class CommentController {

    @Autowired
    private CommentServiceImpl commentServiceImp;

    @PostMapping("/commentinsert")
    public ResponseResult commentinsert(@RequestParam("comment") String comment, @CurrentUserId String memberid, @RequestParam("file") MultipartFile file) {
        JSONObject aConverter = new JSONObject();
        JSONObject jo = JSONObject.parseObject(comment);
        Comment comment1 = (Comment) JSON.toJavaObject(jo, Comment.class);
        return commentServiceImp.insert(comment1, memberid, file);
    }

    @GetMapping("/commentselect")
    public ResponseResult goodsselect() {

        return commentServiceImp.select();
    }

    @DeleteMapping("/commentdelete")
    public ResponseResult commentdelect(@CurrentUserId String id) {

        return commentServiceImp.delete(String.valueOf(id));
    }

    @PutMapping("/commentupdate")
    public ResponseResult goodsupdate(@RequestParam("comment") String comment, @RequestParam("file") MultipartFile file) {

        JSONObject aConverter = new JSONObject();
        JSONObject jo = JSONObject.parseObject(comment);
        Comment comment1 = (Comment) JSON.toJavaObject(jo, Comment.class);
        return commentServiceImp.update(comment1, file);
    }
}
