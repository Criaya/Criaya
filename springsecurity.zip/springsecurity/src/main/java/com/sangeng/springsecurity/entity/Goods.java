package com.sangeng.springsecurity.entity;

import java.io.Serializable;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 
 * </p>
 *
 * @author yj
 * @since 2022-03-06
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class Goods implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 商品id主键
     */
    @TableId(value = "good_id", type = IdType.AUTO)
    private Integer goodId;

    /**
     * 分类id
     */
    private Integer catId;

    /**
     * 商品名称
     */
    private String goodsName;

    /**
     * 商品价格
     */
    private Integer goodPrice;

    /**
     * 商品介绍
     */
    private String goodIntroduce;

    /**
     * 商品库存
     */
    private Integer goodsNumber;

    /**
     * 商品大图标
     */
    private String goodBigLogo;

    /**
     * 商品小图标
     */
    private String goodSmallLogo;

    /**
     * 一级分类
     */
    private Integer catOneId;

    /**
     * 二级分类
     */
    private Integer catTwoId;

    /**
     * 三级分类
     */
    private Integer catThreeId;

    /**
     * 可用状态
     */
    private Integer status;

    /**
     * 商家id
     */
    private String shopid;

}
