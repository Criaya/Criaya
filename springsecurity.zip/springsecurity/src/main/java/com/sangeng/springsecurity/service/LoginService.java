package com.sangeng.springsecurity.service;

import com.sangeng.springsecurity.entity.Membervip;
import com.sangeng.springsecurity.enty.ResponseResult;
import com.sangeng.springsecurity.enty.User;

public interface LoginService {
    ResponseResult longin(User user);

    ResponseResult logout();

    ResponseResult register(Membervip membervip, Long role);
}
