package com.sangeng.springsecurity.entity;

import java.io.Serializable;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 
 * </p>
 *
 * @author yj
 * @since 2022-03-06
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class Cat implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 商品菜单id主键
     */
    @TableId(value = "cat_id", type = IdType.AUTO)
    private Integer catId;

    /**
     * 类别名称
     */
    private String catName;

    /**
     * 父级id，0为一级目录
     */
    private Integer catPid;

    /**
     * 类别级别
     */
    private Integer catLevel;

    /**
     * 是否删除
     */
    private Boolean catDelete;

    /**
     * 类别图片
     */
    private String catIcon;


}
