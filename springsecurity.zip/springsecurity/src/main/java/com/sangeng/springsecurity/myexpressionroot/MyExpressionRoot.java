package com.sangeng.springsecurity.myexpressionroot;

import com.sangeng.springsecurity.enty.Loginuser;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import java.util.List;
@Component("myexpressionroot")
public class MyExpressionRoot {
    public boolean hasAuthority(String authority){
        //获取权限
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        Loginuser loginuser = (Loginuser) authentication.getPrincipal();
        List<String> list = loginuser.getList();
        //验证
        //并且在对应的controller上加上
        // @PreAuthorize("@myexpressionroot.hasAuthority('system:dept:index')")
        return list.contains(authority);


    }
}
