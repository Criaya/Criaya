package com.sangeng.springsecurity.entity;

import java.io.Serializable;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 
 * </p>
 *
 * @author yj
 * @since 2022-03-06
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class Comment implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 评论id主键
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 会员id
     */
    private String memberId;

    /**
     * nic
     */
    private String nickname;

    /**
     * 订单号
     */
    private String orderCode;

    /**
     * 商品id
     */
    private Integer itemId;

    /**
     * 评论图片
     */
    private String image;

    /**
     * 评论视频
     */
    private String film;

    /**
     * 评论信息
     */
    private String info;

    /**
     * 分数（1-5）
     */
    private Integer score;

    /**
     * 点赞数
     */
    private Integer likes;

    /**
     * 有效状态（0可用，1不可用)
     */
    private Integer status;


}
