package com.sangeng.springsecurity.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.io.Serializable;

import com.baomidou.mybatisplus.annotation.FieldFill;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 *
 * </p>
 *
 * @author yj
 * @since 2022-03-06
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class Aftermarkets implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 售后id
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 用户昵称
     */
    private String nickname;

    /**
     * 金额
     */
    private Double money;

    /**
     * 详情
     */
    private String info;

    /**
     * 状态
     */
    private Integer status;

    /**
     * 手机号
     */
    private String tel;

    /**
     * 支付方式
     */

    private String payType;

    /**
     * 关联订单号
     */
    private String ordercode;

    /**
     * 修改时间
     */
    @TableField(fill = FieldFill.INSERT_UPDATE)

    private LocalDateTime updated;

    /**
     * 创建时间
     */
    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime created;


}
