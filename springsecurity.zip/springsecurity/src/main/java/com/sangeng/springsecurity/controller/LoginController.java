package com.sangeng.springsecurity.controller;

import com.sangeng.springsecurity.entity.Membervip;
import com.sangeng.springsecurity.enty.ResponseResult;
import com.sangeng.springsecurity.enty.User;
import com.sangeng.springsecurity.service.impl.LoginServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/user")
public class LoginController {
    @Autowired
    private LoginServiceImpl loginService;

    @PostMapping("/login")
    public ResponseResult login(@RequestBody User user) {

        return loginService.longin(user);
    }

    @PostMapping("/logout")
    public ResponseResult logout() {

        return loginService.logout();
    }

    @PostMapping("/register/{role}")
    public ResponseResult register(@RequestBody Membervip membervip, @PathVariable("role") Long role) {

        return loginService.register(membervip, role);
    }

}
