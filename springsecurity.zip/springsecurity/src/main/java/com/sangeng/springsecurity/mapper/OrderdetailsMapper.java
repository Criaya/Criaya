package com.sangeng.springsecurity.mapper;

import com.sangeng.springsecurity.entity.Orderdetails;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author yj
 * @since 2022-03-06
 */
@Mapper
@Repository
public interface OrderdetailsMapper extends BaseMapper<Orderdetails> {

}
