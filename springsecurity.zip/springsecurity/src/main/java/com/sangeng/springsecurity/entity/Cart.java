package com.sangeng.springsecurity.entity;

import java.io.Serializable;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 
 * </p>
 *
 * @author yj
 * @since 2022-03-06
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class Cart implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 购物车id
     */
    @TableId(value = "car_id", type = IdType.AUTO)
    private Integer cart_id;

    /**
     * 商品id
     */
    private Integer goods_id;

    /**
     * 商品名字
     */
    private String goods_name;

    /**
     * 数量
     */
    private Integer num;

    /**
     * 商品价格
     */
    private Integer good_price;

    /**
     * 商品图标
     */
    private String goods_small_logo;

    /**
     * 检查是否可用
     */
    private Integer checked;

    /**
     * 会员id
     */
    private String memberid;

}
