package com.sangeng.springsecurity.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.sangeng.springsecurity.entity.Cart;
import com.sangeng.springsecurity.enty.ResponseResult;
import com.sangeng.springsecurity.mapper.CartMapper;
import com.sangeng.springsecurity.service.ICartService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author yj
 * @since 2022-03-06
 */
@Service
public class CartServiceImpl implements ICartService {
    @Autowired
    private CartMapper cartMapper;

    @Override
    public ResponseResult insertcart(Cart cart, String memberud) {
        Cart mycaet = new Cart();
        cart.setMemberid(memberud);
        cartMapper.insert(cart);
        return new ResponseResult(200, "添加成功");
    }

    @Override
    public ResponseResult selectcart(String memberid) {
        List<Cart> carts = cartMapper.selectcart(memberid);

        return new ResponseResult(200, carts);
    }

    @Override
    public ResponseResult updatecart(Cart cart) {

        cartMapper.updatecart(cart);
        return new ResponseResult(200, "修改成功");
    }

    @Override
    public ResponseResult deletecart(Integer cartid) {
        cartMapper.deletecart(cartid);
        return new ResponseResult(200, "删除成功");
    }
}
