package com.sangeng.springsecurity.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.sangeng.springsecurity.entity.Dict;
import com.sangeng.springsecurity.enty.ResponseResult;
import com.sangeng.springsecurity.mapper.DictMapper;
import com.sangeng.springsecurity.service.IDictService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author yj
 * @since 2022-03-06
 */
@Service
public class DictServiceImpl implements IDictService {
    @Autowired
    private DictMapper dictMapper;

    @Override
    public ResponseResult insertdict(Dict dict) {
        List<Dict> dicts = dictMapper.selectList(null);
        int count = 0;
        for (Dict adict : dicts) {
            if (dict.getDict().equals(adict.getDict())) {
                Integer num = adict.getNum() + 1;
                adict.setNum(num);
                LambdaQueryWrapper<Dict> dictLambdaQueryWrapper = new LambdaQueryWrapper<>();
                dictLambdaQueryWrapper.eq(Dict::getId, adict.getId());
                dictMapper.update(adict, dictLambdaQueryWrapper);
                count++;
            }
        }
        if (count == 0) {
            dictMapper.insert(dict);
        }
        //这里可能需要不错所搜功能
        return null;
    }

    @Override
    public ResponseResult updatedict(Dict dict) {
        LambdaQueryWrapper<Dict> dictLambdaQueryWrapper = new LambdaQueryWrapper<>();
        dictLambdaQueryWrapper.eq(Dict::getId, dict.getId());
        dictMapper.update(dict, dictLambdaQueryWrapper);
        return new ResponseResult(200, "修改成功");
    }

    @Override
    public ResponseResult selectdict() {
        List<Dict> dicts = dictMapper.selectList(null);
        return new ResponseResult(200, dicts);
    }

    @Override
    public ResponseResult deletedict(String dictid) {
        dictMapper.deleteById(dictid);
        return new ResponseResult(200, "删除成功");
    }
}
