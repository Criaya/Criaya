package com.sangeng.springsecurity.entity;

import java.math.BigDecimal;
import java.io.Serializable;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 
 * </p>
 *
 * @author yj
 * @since 2022-03-06
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class Orderdetails implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 订单详情id
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 商品id
     */
    private String itemId;

    /**
     * 订单号
     */
    private String orderCode;

    /**
     * 购买数量
     */
    private Integer itemNum;

    /**
     * 商品标题
     */
    private String itemTitle;

    /**
     * 商品单价
     */
    private Double itemPrice;

    /**
     * 商品总金额
     */
    private Double  total;

    /**
     * 商品图片
     */
    private String itemImage;


}
