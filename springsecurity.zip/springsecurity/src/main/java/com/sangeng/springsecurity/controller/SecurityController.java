package com.sangeng.springsecurity.controller;

import com.sangeng.springsecurity.enty.ResponseResult;
import com.sangeng.springsecurity.enty.User;
import com.sangeng.springsecurity.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
public class SecurityController {
    @Autowired
    UserMapper userMapper;

    @RequestMapping("/hello")
    @PreAuthorize("hasAuthority('system:dept:index')")
//    @PreAuthorize("@myexpressionroot.hasAuthority('system:dept:index')")
    public List<User> Hello() {
        List<User> users = userMapper.selectList(null);
        return users;
    }

    @GetMapping("/token")
    public ResponseResult gettoken(HttpServletRequest request) {
        String token = request.getHeader("token");

        return new ResponseResult(200, token);
    }
}
