package com.sangeng.springsecurity.service;

import com.sangeng.springsecurity.entity.Comment;
import com.baomidou.mybatisplus.extension.service.IService;
import com.sangeng.springsecurity.enty.ResponseResult;
import org.springframework.web.multipart.MultipartFile;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author yj
 * @since 2022-03-06
 */
public interface ICommentService  {
      ResponseResult insert(Comment comment, String memberid, MultipartFile filename);
      ResponseResult update(Comment comment,  MultipartFile filename);
      ResponseResult select();
      ResponseResult delete(String id);



}
