package com.sangeng.springsecurity.controller;


import com.sangeng.springsecurity.enty.ResponseResult;
import com.sangeng.springsecurity.service.impl.CatServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author yj
 * @since 2022-03-06
 */
@RestController
@RequestMapping("/cat")
public class CatController {
    @Autowired
    private CatServiceImpl catServiceImp;

    @GetMapping("/selectcat")
    public ResponseResult selectcat(@RequestParam("catid") String catid) {
        return catServiceImp.selectcat(catid);
    }
}
