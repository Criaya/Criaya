package com.sangeng.springsecurity.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.sangeng.springsecurity.entity.Aftermarkets;
import com.sangeng.springsecurity.entity.Membervip;
import com.sangeng.springsecurity.entity.Orders;
import com.sangeng.springsecurity.enty.ResponseResult;
import com.sangeng.springsecurity.mapper.AftermarketsMapper;
import com.sangeng.springsecurity.mapper.MembervipMapper;
import com.sangeng.springsecurity.mapper.OrdersMapper;
import com.sangeng.springsecurity.service.IAftermarketsService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.LinkedList;
import java.util.List;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author yj
 * @since 2022-03-06
 */
@Service
public class AftermarketsServiceImpl implements IAftermarketsService {
    @Autowired
    private MembervipMapper membervipMapper;
    @Autowired
    private OrdersMapper ordersMapper;
    @Autowired
    private AftermarketsMapper aftermarketsMapper;

    @Override
    public ResponseResult insertaftermarketsservice() {
        Aftermarkets aftermarkets = new Aftermarkets();
        List<Orders> orders = ordersMapper.selectList(null);
        List<Orders> ordersList = new LinkedList<>();
        for (Orders order : orders) {
            if (order.getStatus() == 3) {
                ordersList.add(order);
            }
        }
        for (Orders aorder : ordersList) {
            Integer memberId = aorder.getMemberId();
            Membervip membervip = membervipMapper.selectById(memberId);
            aftermarkets.setNickname(membervip.getNickname());
            aftermarkets.setTel(membervip.getTel());
            aftermarkets.setMoney(aorder.getPaymentMoney());
            aftermarkets.setOrdercode(aorder.getOrderCode());
            aftermarketsMapper.insert(aftermarkets);
            LambdaQueryWrapper<Orders> ordersLambdaQueryWrapper = new LambdaQueryWrapper<>();
            ordersLambdaQueryWrapper.eq(Orders::getId, aorder.getId());
            aorder.setStatus(4);
            ordersMapper.update(aorder, ordersLambdaQueryWrapper);
        }
        return new ResponseResult(200, "添加成功");
    }

    @Override
    public ResponseResult updateaftermarketsservice(Aftermarkets aftermarkets) {
        LambdaQueryWrapper<Aftermarkets> aftermarketsLambdaQueryWrapper = new LambdaQueryWrapper<>();
        aftermarketsLambdaQueryWrapper.eq(Aftermarkets::getId, aftermarkets.getId());
        aftermarketsMapper.update(aftermarkets, aftermarketsLambdaQueryWrapper);
        return new ResponseResult(200, "修改成功");
    }

    @Override
    public ResponseResult selectaftermarketsservice() {
        List<Aftermarkets> aftermarkets = aftermarketsMapper.selectList(null);
        return new ResponseResult(200, aftermarkets);
    }

    @Override
    public ResponseResult delectaftermarketsservice(String aftermarketid) {
        aftermarketsMapper.deleteById(aftermarketid);
        return new ResponseResult(200, "删除成功");
    }
}
