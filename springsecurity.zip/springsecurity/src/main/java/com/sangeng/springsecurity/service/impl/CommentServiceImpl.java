package com.sangeng.springsecurity.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.sangeng.springsecurity.entity.Comment;
import com.sangeng.springsecurity.entity.Goods;
import com.sangeng.springsecurity.entity.Membervip;
import com.sangeng.springsecurity.enty.ResponseResult;
import com.sangeng.springsecurity.mapper.CommentMapper;
import com.sangeng.springsecurity.mapper.MembervipMapper;
import com.sangeng.springsecurity.mapper.OrdersMapper;
import com.sangeng.springsecurity.service.ICommentService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.List;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author yj
 * @since 2022-03-06
 */
@Service
public class CommentServiceImpl implements ICommentService {
    @Autowired
    private OrdersMapper ordersMapper;
    @Autowired
    private MembervipMapper membervipMapper;
    @Autowired
    private CommentMapper commentMapper;

    @Override
    public ResponseResult insert(Comment comment, String memberid, MultipartFile filename) {
        //上传地址并且地址写进数据库
        if (filename.isEmpty()) {
            return new ResponseResult<>(300, "上传文件为空");
        }
        String originalFilename = filename.getOriginalFilename();
        String fileName = System.currentTimeMillis() + "." + originalFilename.substring(originalFilename.lastIndexOf(".") + 1);
        String pathName = "D:\\springsecurity\\src\\main\\resources\\static\\";
        File dest = new File(pathName + fileName);
        String path;
        if (originalFilename.substring(originalFilename.lastIndexOf(".")).equals(".png") || originalFilename.substring(originalFilename.lastIndexOf(".")).equals(".gif") || originalFilename.substring(originalFilename.lastIndexOf(".")).equals(".jpg")) {
            if (dest.getParentFile().exists()) {
                dest.getParentFile().mkdirs();
            }
            try {
                filename.transferTo(dest);
            } catch (IOException e) {
                e.printStackTrace();
            }
            path = "http://" + "localhost" + ":" + "8888/" + fileName;
        } else {
            return new ResponseResult(300, "图片格式错误");
        }
        //添加商品
        Membervip membervip = membervipMapper.selectById(memberid);
        comment.setMemberId(memberid);
        comment.setNickname(membervip.getNickname());
        comment.setImage(path);
        commentMapper.insert(comment);
        return new ResponseResult(200, "添加成功");

    }

    @Override
    public ResponseResult update(Comment comment, MultipartFile filename) {
        //上传地址并且地址写进数据库
        if (filename.isEmpty()) {
            return new ResponseResult<>(300, "上传文件为空");
        }
        String originalFilename = filename.getOriginalFilename();
        String fileName = System.currentTimeMillis() + "." + originalFilename.substring(originalFilename.lastIndexOf(".") + 1);
        String pathName = "D:\\springsecurity\\src\\main\\resources\\static\\";
        File dest = new File(pathName + fileName);
        String path;
        if (originalFilename.substring(originalFilename.lastIndexOf(".")).equals(".png") || originalFilename.substring(originalFilename.lastIndexOf(".")).equals(".gif") || originalFilename.substring(originalFilename.lastIndexOf(".")).equals(".jpg")) {
            if (dest.getParentFile().exists()) {
                dest.getParentFile().mkdirs();
            }
            try {
                filename.transferTo(dest);
            } catch (IOException e) {
                e.printStackTrace();
            }
            path = "http://" + "localhost" + ":" + "8888/" + fileName;
        } else {
            return new ResponseResult(300, "图片格式错误");
        }

        LambdaQueryWrapper<Comment> goodsLambdaQueryWrapper = new LambdaQueryWrapper<>();
        goodsLambdaQueryWrapper.eq(Comment::getId, comment.getId());
        comment.setImage(path);
        commentMapper.update(comment, goodsLambdaQueryWrapper);
        return new ResponseResult(200, "修改成功");
    }

    @Override
    public ResponseResult select() {
        List<Comment> comments = commentMapper.selectList(null);
        return new ResponseResult(200, comments);
    }

    @Override
    public ResponseResult delete(String id) {
        LambdaQueryWrapper<Comment> commentLambdaQueryWrapper = new LambdaQueryWrapper<>();
        commentLambdaQueryWrapper.eq(Comment::getMemberId, id);
        commentMapper.delete(commentLambdaQueryWrapper);
        return new ResponseResult(200, "删除成功");
    }
}
