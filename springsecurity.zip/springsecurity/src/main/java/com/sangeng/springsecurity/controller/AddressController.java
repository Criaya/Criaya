package com.sangeng.springsecurity.controller;


import com.sangeng.springsecurity.annotation.CurrentUserId;
import com.sangeng.springsecurity.entity.Address;
import com.sangeng.springsecurity.enty.ResponseResult;
import com.sangeng.springsecurity.service.impl.AddressServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author yj
 * @since 2022-03-06
 */
@RestController
@RequestMapping("/address")
public class AddressController {
    @Autowired
    private AddressServiceImpl addressServiceImp;

    @PreAuthorize("hasAuthority('system:user:index')")
    @PostMapping("/addressinsert")
    public ResponseResult addressinsert(@RequestBody Address address, @CurrentUserId String memeberid) {
        return addressServiceImp.adderssinsert(address, memeberid);
    }

    @PreAuthorize("hasAuthority('system:user:index')")
    @GetMapping("/addressselect")
    public ResponseResult addressselect(@CurrentUserId String memeberid) {
        return addressServiceImp.adderssselect(memeberid);
    }

    @PreAuthorize("hasAuthority('system:user:index')")
    @DeleteMapping("/addressdelete")
    public ResponseResult addressdelect(@RequestBody Address address) {
        return addressServiceImp.adderssselect(String.valueOf(address.getId()));
    }

    @PreAuthorize("hasAuthority('system:user:index')")
    @PutMapping("/addressupdate")
    public ResponseResult addressupdate(@RequestBody Address address, @CurrentUserId String memberid) {
        return addressServiceImp.adderssupdate(address, memberid);
    }
}
