package com.sangeng.springsecurity.controller;


import com.sangeng.springsecurity.entity.Goodspic;
import com.sangeng.springsecurity.enty.ResponseResult;
import com.sangeng.springsecurity.service.impl.GoodspicServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import org.springframework.web.multipart.MultipartFile;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author yj
 * @since 2022-03-06
 */
@RestController
@RequestMapping("/goodspic")
public class GoodspicController {
    @Autowired
    private GoodspicServiceImpl goodspicServiceImp;

    @PostMapping("/goodspicinsert")
    public ResponseResult insertpic(@RequestParam("goodsid") Integer goods, MultipartFile[] filename) {
        return goodspicServiceImp.insertpic(goods, filename);
    }

    @PutMapping("/updatepic")
    ResponseResult updatepic(Goodspic goodspic, MultipartFile[] filename) {
        return goodspicServiceImp.updatepic(goodspic, filename);
    }

    @GetMapping("/selectpic")
    ResponseResult selectpic(@RequestParam("goodsid") Integer goodsid) {
        return goodspicServiceImp.selectpic(goodsid);
    }

    @DeleteMapping("/")
    ResponseResult deletepic(@RequestParam("goodspic") String goodspic) {
        return goodspicServiceImp.deletepic(goodspic);
    }
}
