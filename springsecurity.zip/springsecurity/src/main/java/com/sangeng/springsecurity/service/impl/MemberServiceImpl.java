package com.sangeng.springsecurity.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.sangeng.springsecurity.entity.Address;
import com.sangeng.springsecurity.entity.Membervip;
import com.sangeng.springsecurity.enty.ResponseResult;
import com.sangeng.springsecurity.mapper.MembervipMapper;
import com.sangeng.springsecurity.service.IMemberService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author yj
 * @since 2022-03-06
 */
@Service
public class MemberServiceImpl implements IMemberService {
    @Autowired
    private MembervipMapper membervipMapper;

    @Override
    public ResponseResult Membervipupdate(Membervip membervip) {
        LambdaQueryWrapper<Membervip> addressLambdaQueryWrapper = new LambdaQueryWrapper<>();
        addressLambdaQueryWrapper.eq(Membervip::getId, membervip.getId());
        membervipMapper.update(membervip, addressLambdaQueryWrapper);
        return new ResponseResult(200, "修改成功");
    }
}
