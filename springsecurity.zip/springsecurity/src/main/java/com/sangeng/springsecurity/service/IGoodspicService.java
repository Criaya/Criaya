package com.sangeng.springsecurity.service;

import com.sangeng.springsecurity.entity.Goodspic;
import com.baomidou.mybatisplus.extension.service.IService;
import com.sangeng.springsecurity.enty.ResponseResult;
import org.springframework.web.multipart.MultipartFile;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author yj
 * @since 2022-03-06
 */
public interface IGoodspicService {
    ResponseResult insertpic(Integer goods, MultipartFile[] filename);

    ResponseResult updatepic(Goodspic goodspic, MultipartFile[] filename);

    ResponseResult selectpic(Integer goodsid);

    ResponseResult deletepic(String goodspic);

}
