package com.sangeng.springsecurity.controller;


import com.sangeng.springsecurity.annotation.CurrentUserId;
import com.sangeng.springsecurity.entity.Orderdetails;
import com.sangeng.springsecurity.entity.Orders;
import com.sangeng.springsecurity.enty.ResponseResult;
import com.sangeng.springsecurity.service.impl.OrderServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author yj
 * @since 2022-03-06
 */
@RestController
@RequestMapping("/order")
public class OrderController {
    @Autowired
    private OrderServiceImpl orderServiceImp;

    @PostMapping("/ordersinsert")
    public ResponseResult ordersinsert(@RequestBody Orderdetails orderdetails, @CurrentUserId String memberid) {
        return orderServiceImp.ordersinsert(orderdetails, memberid);
    }

    @PutMapping("/ordersupdate")
    public ResponseResult ordersupdate(@RequestBody Orders orders) {
        return orderServiceImp.ordersupdate(orders);
    }

    @GetMapping("/ordersselect")
    public ResponseResult ordersselect() {
        return orderServiceImp.ordersselect();
    }

    @GetMapping("/cusselect")
    public ResponseResult cusselect(@CurrentUserId String memberid) {
        return orderServiceImp.cussselect(memberid);
    }

    @DeleteMapping("/ordersdelete")
    public ResponseResult ordersdelete(@RequestBody Orders orders) {
        return orderServiceImp.ordersdelete(orders);
    }
}
