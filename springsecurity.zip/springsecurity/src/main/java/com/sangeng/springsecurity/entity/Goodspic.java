package com.sangeng.springsecurity.entity;

import java.io.Serializable;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 
 * </p>
 *
 * @author yj
 * @since 2022-03-06
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class Goodspic implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 图片id主键
     */
    @TableId(value = "picsid", type = IdType.AUTO)
    private Integer picsid;

    /**
     * 商品id
     */
    private Integer goodsid;

    /**
     * 商品地址
     */
    private String picsmid;


}
