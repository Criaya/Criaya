package com.sangeng.springsecurity.service.impl;

import com.sangeng.springsecurity.entity.Express;
import com.sangeng.springsecurity.entity.Goods;
import com.sangeng.springsecurity.enty.ResponseResult;
import com.sangeng.springsecurity.mapper.ExpressMapper;
import com.sangeng.springsecurity.mapper.GoodsMapper;
import com.sangeng.springsecurity.service.IExpressService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author yj
 * @since 2022-03-06
 */
@Service
public class ExpressServiceImpl implements IExpressService {
    @Autowired
    private ExpressMapper expressMapper;
    @Autowired
    private GoodsMapper goodsMapper;

    @Override
    public ResponseResult select() {
        HashMap hashMap=new HashMap<String, Object>();
        List<Goods> good = new LinkedList();
        List<Express> expresses = expressMapper.selectList(null);
        for (Express express:expresses){
            Goods goods = goodsMapper.selectById(express.getGoodsid());
            good.add(goods);
        }
        hashMap.put("goods",good);
        hashMap.put("expresses",expresses);
        return new ResponseResult(200,hashMap);
    }

    @Override
    public ResponseResult delete(Integer exid) {
        return null;
    }
}
