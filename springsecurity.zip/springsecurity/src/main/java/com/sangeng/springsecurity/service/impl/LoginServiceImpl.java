package com.sangeng.springsecurity.service.impl;

import com.sangeng.springsecurity.entity.Membervip;
import com.sangeng.springsecurity.entity.SysRoleMenu;
import com.sangeng.springsecurity.entity.SysUserRole;
import com.sangeng.springsecurity.enty.Loginuser;
import com.sangeng.springsecurity.enty.ResponseResult;
import com.sangeng.springsecurity.enty.User;
import com.sangeng.springsecurity.mapper.MembervipMapper;
import com.sangeng.springsecurity.mapper.UserMapper;
import com.sangeng.springsecurity.service.LoginService;
import com.sangeng.springsecurity.util.JwtUtil;
import com.sangeng.springsecurity.util.RedisCache;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Objects;

@Transactional
@Service
public class LoginServiceImpl implements LoginService {
    @Autowired
    private AuthenticationManager authenticationManager;
    @Autowired
    private RedisCache redisCache;
    @Autowired
    private UserMapper userMapper;
    @Autowired
    private SysUserRoleServiceImpl sysUserRoleService;
    @Autowired
    private SysRoleMenuServiceImpl sysRoleMenuService;
    @Autowired
    private MembervipMapper membervipMapper;

    @Override
    public ResponseResult longin(User user) {
        //进行认证
        UsernamePasswordAuthenticationToken passwordAuthenticationToken = new UsernamePasswordAuthenticationToken(user.getUserName(), user.getPassword());
        Authentication authenticate = authenticationManager.authenticate(passwordAuthenticationToken);

        //认证不成功返回错误信息
        if (Objects.isNull(authenticate)) {
            //throw new RuntimeException("登入失败");
            return new ResponseResult(200, "登入失败");
        }

        //userid转化成jwt
        Loginuser loginuser = (Loginuser) authenticate.getPrincipal();
        String userId = loginuser.getUser().getId().toString();
        String jwt = JwtUtil.createJWT(userId);
        HashMap<String, String> map = new HashMap<String, String>();
        map.put("token", jwt);

        //把完整的用户信息存入redis
        redisCache.setCacheObject("login:" + userId, loginuser);
        return new ResponseResult(200, "登入成功", map);
    }

    @Override
    public ResponseResult logout() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        Loginuser loginUser = (Loginuser) authentication.getPrincipal();
        Long userid = loginUser.getUser().getId();
        redisCache.deleteObject("login:" + userid);
        return new ResponseResult(200, "退出成功");
    }

    @Override
    public ResponseResult register(Membervip membervip, Long role) {
        //插入membervip
        membervipMapper.insert(membervip);
        //验证账号是否唯一
        User user = new User();
        user.setId(Long.valueOf(membervip.getId()));
        user.setPassword(membervip.getPassword());
        user.setUserName(membervip.getUsername());
        List<User> users = userMapper.selectList(null);
        for (User userList : users) {
            if (userList.getUserName().equals(user.getUserName())) {
                return new ResponseResult(300, "该用户以拥有请重新注册");
            }
        }
        BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();
        String encode = bCryptPasswordEncoder.encode(user.getPassword());
        user.setPassword(encode);
        int insert = userMapper.insert(user);
        if (role == 1) {
            //添加人物角色关系
            SysUserRole sysUserRole = new SysUserRole();
            sysUserRole.setUserId(user.getId());
            sysUserRole.setRoleId(Long.valueOf(1));
            sysUserRoleService.insertrole(sysUserRole);
//            //添加角色权限关系
//            SysRoleMenu sysRoleMenu = new SysRoleMenu();
//            sysRoleMenu.setRoleId(Long.valueOf(1));
//            sysRoleMenu.setMenuId(Long.valueOf(1));
        } else {
            //添加人物角色关系
            SysUserRole sysUserRole = new SysUserRole();
            sysUserRole.setUserId(user.getId());
            sysUserRole.setRoleId(Long.valueOf(2));
            sysUserRoleService.insertrole(sysUserRole);
//            //添加角色权限关系
//            SysRoleMenu sysRoleMenu = new SysRoleMenu();
//            sysRoleMenu.setRoleId(Long.valueOf(2));
//            sysRoleMenu.setMenuId(Long.valueOf(2));
        }

        return new ResponseResult(200, "注册成功");
    }
}

