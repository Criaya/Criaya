package com.sangeng.springsecurity.entity;

import java.io.Serializable;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * <p>
 * 
 * </p>
 *
 * @author yj
 * @since 2022-03-06
 */
@Data
@EqualsAndHashCode(callSuper = false)
public class Dict implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 热词id主键
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Integer id;

    /**
     * 词
     */
    private String dict;

    /**
     * 数量
     */
    private Integer num;

    /**
     * 有效状态(0不可用，1可用)
     */
    private Integer status;


}
