package com.sangeng.springsecurity.controller;


import com.sangeng.springsecurity.annotation.CurrentUserId;
import com.sangeng.springsecurity.entity.Fadeback;
import com.sangeng.springsecurity.enty.ResponseResult;
import com.sangeng.springsecurity.service.impl.FadebackServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author yj
 * @since 2022-03-06
 */
@RestController
@RequestMapping("/fadeback")
public class FadebackController {
    @Autowired
    private FadebackServiceImpl fadebackServiceImp;

    @PostMapping("/fadebackinsert")
    public ResponseResult fadebackinsert(@RequestBody Fadeback fadeback, @CurrentUserId String id) {
        return fadebackServiceImp.insertfade(fadeback, id);
    }

    @PutMapping("/fadebackupdate")
    public ResponseResult fadebackupdate(@RequestBody Fadeback fadeback) {
        return fadebackServiceImp.updatefade(fadeback);
    }

    @GetMapping("/fadebackselect")
    public ResponseResult fadebackselect(@RequestBody Fadeback fadeback) {
        return fadebackServiceImp.selectfade();
    }

    @GetMapping("/fadebackselectone")
    public ResponseResult fadebackselectone(@CurrentUserId String id) {
        return fadebackServiceImp.selectonefade(id);
    }

    @DeleteMapping("/fadebackdelete")
    public ResponseResult fadebackdelete(@RequestParam("fakeid") String fakeid) {
        return fadebackServiceImp.deletefade(Integer.valueOf(fakeid));
    }
}
