package com.sangeng.springsecurity.service;

import com.sangeng.springsecurity.entity.SysRole;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 角色表 服务类
 * </p>
 *
 * @author yj
 * @since 2022-03-06
 */
public interface ISysRoleService extends IService<SysRole> {

}
