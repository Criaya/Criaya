package com.sangeng.springsecurity.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.sangeng.springsecurity.entity.Cat;
import com.sangeng.springsecurity.entity.Goods;
import com.sangeng.springsecurity.entity.Goodspic;
import com.sangeng.springsecurity.enty.ResponseResult;
import com.sangeng.springsecurity.mapper.CatMapper;
import com.sangeng.springsecurity.mapper.GoodsMapper;
import com.sangeng.springsecurity.mapper.GoodspicMapper;
import com.sangeng.springsecurity.service.IGoodsService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.List;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author yj
 * @since 2022-03-06
 */
@Service
public class GoodsServiceImpl implements IGoodsService {
    @Autowired
    private GoodsMapper goodsMapper;
    @Autowired
    private GoodspicMapper goodspicMapper;

    @Override
    public ResponseResult insertgods(Goods goods, String shopid, MultipartFile filename) {
        //上传地址并且地址写进数据库
        if (filename.isEmpty()) {
            return new ResponseResult<>(300, "上传文件为空");
        }
        String originalFilename = filename.getOriginalFilename();
        String fileName = System.currentTimeMillis() + "." + originalFilename.substring(originalFilename.lastIndexOf(".") + 1);
        String pathName = "D:\\springsecurity\\src\\main\\resources\\static\\";
        File dest = new File(pathName + fileName);
        String path;
        if (originalFilename.substring(originalFilename.lastIndexOf(".")).equals(".png") || originalFilename.substring(originalFilename.lastIndexOf(".")).equals(".gif") || originalFilename.substring(originalFilename.lastIndexOf(".")).equals(".jpg")) {
            if (dest.getParentFile().exists()) {
                dest.getParentFile().mkdirs();
            }
            try {
                filename.transferTo(dest);
            } catch (IOException e) {
                e.printStackTrace();
            }
            path = "http://" + "localhost" + ":" + "8888/" + fileName;
        } else {
            return new ResponseResult(300, "图片格式错误");
        }
        //添加商品
        goods.setGoodBigLogo(path);
        goods.setShopid(shopid);
        goodsMapper.insert(goods);
        return new ResponseResult(200, "添加成功");
    }

    @Override
    public ResponseResult selectgods(String shopid) {
        LambdaQueryWrapper<Goods> goodsLambdaQueryWrapper = new LambdaQueryWrapper<>();
        goodsLambdaQueryWrapper.eq(Goods::getShopid, shopid);
        List<Goods> goods = goodsMapper.selectList(goodsLambdaQueryWrapper);
        return new ResponseResult(200, goods);
    }

    @Override
    public ResponseResult updategods(Goods goods, MultipartFile filename) {
        //上传地址并且地址写进数据库
        if (filename.isEmpty()) {
            return new ResponseResult<>(300, "上传文件为空");
        }
        String originalFilename = filename.getOriginalFilename();
        String fileName = System.currentTimeMillis() + "." + originalFilename.substring(originalFilename.lastIndexOf(".") + 1);
        String pathName = "D:\\springsecurity\\src\\main\\resources\\static\\";
        File dest = new File(pathName + fileName);
        String path;
        if (originalFilename.substring(originalFilename.lastIndexOf(".")).equals(".png") || originalFilename.substring(originalFilename.lastIndexOf(".")).equals(".gif") || originalFilename.substring(originalFilename.lastIndexOf(".")).equals(".jpg")) {
            if (dest.getParentFile().exists()) {
                dest.getParentFile().mkdirs();
            }
            try {
                filename.transferTo(dest);
            } catch (IOException e) {
                e.printStackTrace();
            }
            path = "http://" + "localhost" + ":" + "8888/" + fileName;
        } else {
            return new ResponseResult(300, "图片格式错误");
        }

        LambdaQueryWrapper<Goods> goodsLambdaQueryWrapper = new LambdaQueryWrapper<>();
        goodsLambdaQueryWrapper.eq(Goods::getGoodId, goods.getGoodId());
        goods.setGoodBigLogo(path);
        goodsMapper.update(goods, goodsLambdaQueryWrapper);
        return new ResponseResult(200, "修改成功");
    }

    @Override
    public ResponseResult deletegods(Integer goodId) {
        goodsMapper.deleteById(goodId);
        return new ResponseResult(200, "删除成功");
    }
}
