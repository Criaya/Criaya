package com.sangeng.springsecurity.controller;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sangeng.springsecurity.annotation.CurrentUserId;
import com.sangeng.springsecurity.entity.Goods;
import com.sangeng.springsecurity.enty.ResponseResult;
import com.sangeng.springsecurity.mapper.GoodsMapper;
import com.sangeng.springsecurity.service.impl.GoodsServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author yj
 * @since 2022-03-06
 */
@RestController
@RequestMapping("/goods")
public class GoodsController {
    @Autowired
    private GoodsServiceImpl goodsServiceImp;

    @PostMapping("/goodsinsert")
    public ResponseResult goodsinsert(@RequestParam("goods") String goods, @CurrentUserId String goodsid, @RequestParam("file") MultipartFile file) {

        JSONObject aConverter = new JSONObject();
        JSONObject jo = JSONObject.parseObject(goods);
        Goods t = (Goods) JSON.toJavaObject(jo, Goods.class);
        return goodsServiceImp.insertgods(t, goodsid, file);
    }

    @GetMapping("/goodsselect")
    public ResponseResult goodsselect(@CurrentUserId String id) {

        return goodsServiceImp.selectgods(id);
    }

    @DeleteMapping("/goodsdelect")
    public ResponseResult goodsdelect(@RequestParam("id") Integer id) {
        return goodsServiceImp.deletegods(id);
    }

    @PutMapping("/goodsupdate")
    public ResponseResult goodsupdate(@RequestParam("goods") String goods, @RequestParam("file") MultipartFile file) {

        JSONObject aConverter = new JSONObject();
        JSONObject jo = JSONObject.parseObject(goods);
        Goods good = (Goods) JSON.toJavaObject(jo, Goods.class);
        return goodsServiceImp.updategods(good, file);
    }
}
