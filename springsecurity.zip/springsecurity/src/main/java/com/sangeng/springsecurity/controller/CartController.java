package com.sangeng.springsecurity.controller;


import com.sangeng.springsecurity.annotation.CurrentUserId;
import com.sangeng.springsecurity.entity.Cart;
import com.sangeng.springsecurity.enty.ResponseResult;
import com.sangeng.springsecurity.service.impl.CartServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author yj
 * @since 2022-03-06
 */
@RestController
@RequestMapping("/cart")
public class CartController {
    @Autowired
    private CartServiceImpl cartServiceImp;

    @PostMapping("/insertcart")
    @PreAuthorize("hasAuthority('system:user:index')")
    public ResponseResult insertcart(@RequestBody Cart cart, @CurrentUserId String userId) {
        System.out.println(userId);
        return cartServiceImp.insertcart(cart, userId);
    }

    @PostMapping("/selectcart")
    @PreAuthorize("hasAuthority('system:user:index')")
    public ResponseResult selectcart(@CurrentUserId String userId) {
        System.out.println(userId);
        return cartServiceImp.selectcart(userId);
    }

    @PutMapping("/updatecart")
    @PreAuthorize("hasAuthority('system:user:index')")
    public ResponseResult updatecart(@RequestBody Cart cart) {

        return cartServiceImp.updatecart(cart);
    }

    @DeleteMapping("/deletecart/{cartid}")
    @PreAuthorize("hasAuthority('system:user:index')")
    public ResponseResult deletecart(@PathVariable("cartid") Integer cartid) {

        return cartServiceImp.deletecart(cartid);
    }
}
