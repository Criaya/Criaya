package com.sangeng.springsecurity.service.impl;

import com.sangeng.springsecurity.entity.SysUser;
import com.sangeng.springsecurity.mapper.SysUserMapper;
import com.sangeng.springsecurity.service.ISysUserService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 用户表 服务实现类
 * </p>
 *
 * @author yj
 * @since 2022-03-06
 */
@Service
public class SysUserServiceImpl extends ServiceImpl<SysUserMapper, SysUser> implements ISysUserService {

}
