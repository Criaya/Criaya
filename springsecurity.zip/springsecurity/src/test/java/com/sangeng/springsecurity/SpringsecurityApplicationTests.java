package com.sangeng.springsecurity;

import com.baomidou.mybatisplus.core.conditions.Wrapper;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.sangeng.springsecurity.entity.*;
import com.sangeng.springsecurity.enty.User;
import com.sangeng.springsecurity.mapper.*;
import com.sangeng.springsecurity.service.impl.SysRoleMenuServiceImpl;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Sort.Order;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

@SpringBootTest
class SpringsecurityApplicationTests {
    @Autowired
    private UserMapper userMapper;

    @Autowired
    private MenuMapper menuMapper;

    @Test
    void contextLoads() {
        LambdaQueryWrapper lambdaQueryWrapper = new LambdaQueryWrapper();
        List<User> users = userMapper.selectList(null);
        System.out.println(users);
        String A = "1500403998363226113";
        System.out.println(menuMapper.selectList(null));
        List<String> list = menuMapper.selectPermsByUserId(Long.valueOf(A));
        System.out.println(list);

//       BCryptPasswordEncoder bCryptPasswordEncoder=new BCryptPasswordEncoder();
//       String encode = bCryptPasswordEncoder.encode("123456");
//       System.out.println(encode);
//       System.out.println(bCryptPasswordEncoder.matches("123456", "$2a$10$rBcKAbVfUP0wlxaYBp9pTeV/K75rjWTYzZgUe0xcWFqXR9ObdqeZe"));

    }

    @Autowired
    private SysRoleMenuServiceImpl sysUserRoleService;

    @Test
    void test() {
//        Orders orders=new Orders();
//        orders.setAddressId(152);
//        orders.setId(Long.valueOf(1559775613));
//        Cart cart=new Cart();
        SysRoleMenu sysUserRole = new SysRoleMenu();
        sysUserRole.setRoleId(Long.valueOf(1));
        sysUserRole.setMenuId(Long.valueOf(123456));
        sysUserRoleService.insertrole(sysUserRole);
    }

    @Autowired
    private CartMapper cartMapper;

    @Test
    void cart() {
//        Cart cart=new Cart();
////        cart.setCartId(66611);
//        cart.setChecked(1);
//        cartMapper.insert(cart);


//        List<Cart> selectcart = cartMapper.selectcart("1500403998363226113");
//        System.out.println(selectcart);
        Cart cart = new Cart();
        cart.setCart_id(6668);
        cart.setChecked(0);
        cart.setGood_price(20);
//        LambdaQueryWrapper<Cart> lambdaQueryWrapper=new LambdaQueryWrapper<>();
//        lambdaQueryWrapper.eq(Cart::getCartid,cart.getCartid());
//        cartMapper.update(cart,lambdaQueryWrapper);
//        System.out.println(cartMapper.updatecart(cart));
        cartMapper.deletecart(cart.getCart_id());
    }

    @Autowired
    private AddressMapper addressMapper;

    @Test
    void ADDRESS() {
//        System.out.println(addressMapper.selectList(null));
//        LambdaQueryWrapper<Address> lambdaQueryWrapper = new LambdaQueryWrapper<>();
//        lambdaQueryWrapper.eq(Address::getId, 1);
        Address address = new Address();
        address.setAddress("zhongshanchun");
        address.setId(4);
//        addressMapper.update(address, lambdaQueryWrapper);
////        addressMapper.insert(address);
//        addressMapper.deleteById(1);
//        LambdaQueryWrapper<Address> addressLambdaQueryWrapper=new LambdaQueryWrapper<>();
//        addressLambdaQueryWrapper.eq(Address::getMemberId,111);
//        List<Address> addresses = addressMapper.selectList(addressLambdaQueryWrapper);
//        System.out.println(addresses);
        LambdaQueryWrapper<Address> addressLambdaQueryWrapper = new LambdaQueryWrapper<>();
        addressLambdaQueryWrapper.eq(Address::getId, address.getId());
        addressMapper.update(address, addressLambdaQueryWrapper);
    }

    @Autowired
    private MembervipMapper membervipMapper;

    @Test
    void member() {
        Membervip membervip = new Membervip();
        membervip.setEmail("@QQ.com");
        membervipMapper.insert(membervip);
        System.out.println("成功");
    }

    @Autowired
    private GoodsMapper goodsMapper;
    @Autowired
    private GoodspicMapper goodspicMapper;

    @Test
    void goods() {
        goodsMapper.deleteById(2);
//        Goods goods=new Goods();
//        goods.setGoodId(1);
//        goods.setGoodsName("华为手机");
//        LambdaQueryWrapper<Goods> goodsLambdaQueryWrapper=new LambdaQueryWrapper<>();
//        goodsLambdaQueryWrapper.eq(Goods::getGoodId,goods.getGoodId());
//        goodsMapper.update(goods,goodsLambdaQueryWrapper);

//        System.out.println(goods);
//        System.out.println(goodspicMapper.selectList(null));
    }

    @Autowired
    private AftermarketsMapper aftermarketsMapper;

    @Test
    void aftermarket() {
//        aftermarketsMapper.selectList(null);
        Aftermarkets aftermarkets = new Aftermarkets();
        aftermarkets.setInfo("华为手机");
        aftermarkets.setId(1);
        LambdaQueryWrapper<Aftermarkets> l = new LambdaQueryWrapper<>();
        l.eq(Aftermarkets::getId, aftermarkets.getId());
        aftermarketsMapper.update(aftermarkets, l);
//        aftermarketsMapper.insert(aftermarkets);
    }

    @Autowired
    private OrdersMapper ordersMapper;

    @Test
    void orders() {
        Orders orders = new Orders();
//        order.setOrderCode(String.valueOf(2));
//        ordersMapper.insert(order);
//        Address address = addressMapper.selectById(3);
//        Integer id = address.getId();
        orders.setAddressId(66666);
        orders.setId(Long.valueOf(3));
        orders.setMemberId(Integer.valueOf(3));
//        ordersMapper.insert(orders);
//        System.out.println("添加成功");
//        LambdaQueryWrapper<Orders> lambdaQueryWrapper=new LambdaQueryWrapper<>();
//        lambdaQueryWrapper.eq(Orders::getId,orders.getId());
//        ordersMapper.update(orders,lambdaQueryWrapper);
//        List<Orders> order = ordersMapper.selectList(null);
//        System.out.println(order);
//        ordersMapper.deleteById(2);
        Random random = new Random();
        String c = "";
        for (int i = 0; i < 6; i++) {
            int i1 = random.nextInt(10);
            c += i1;
        }
        System.out.println(c);
    }

    @Autowired
    private OrderdetailsMapper orderdetailsMapper;

    @Test
    void orderd() {
//        Orderdetails orderdetails=new Orderdetails();
//        orderdetails.setItemId(String.valueOf(666));
//        //订单详情
//        Random random = new Random();
//        String c="";
//        for (int i=0;i<6;i++){
//            int i1 = random.nextInt(10);
//            c+=i1;
//        }
//        orderdetails.setOrderCode(c);
//        Double itemPrice = orderdetails.getItemPrice();
//        Integer itemNum = orderdetails.getItemNum();
////        Double totalPrice= itemNum*itemPrice;
//        orderdetails.setTotal(666.66);
//        orderdetailsMapper.insert(orderdetails);
        System.out.println(membervipMapper.selectById(1));

    }

    @Autowired
    private DictMapper dictMapper;

    @Test
    void dict() {
//        Dict dict=new Dict();
//        dict.setDict("小米");
//        dictMapper.insert(dict);
        LambdaQueryWrapper<Goods> membervipLambdaQueryWrapper = new LambdaQueryWrapper<>();
        membervipLambdaQueryWrapper.eq(Goods::getCatId, 2);
        List<Goods> goods = goodsMapper.selectList(membervipLambdaQueryWrapper);
        System.out.println(goods);
    }

    @Autowired
    private ExpressMapper expressMapper;

    @Test
    void ex() {
//        Express express=new Express();
//        express.setExpressName("百事快递");
//        expressMapper.insert(express);
//        Goodspic goodspic=new Goodspic();
//        goodspic.setGoodsid(1);
//        goodspicMapper.insert(goodspic );
        HashMap hashMap = new HashMap<String, Object>();
        List<Goods> good = new LinkedList();
        List<Express> expresses = expressMapper.selectList(null);
        for (Express express : expresses) {
            Goods goods = goodsMapper.selectById(express.getGoodsid());
            good.add(goods);
        }
        hashMap.put("goods", good);
        hashMap.put("expresses", expresses);
        System.out.println(hashMap);
    }
}
